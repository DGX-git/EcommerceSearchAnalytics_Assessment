const { DataTypes } = require("sequelize");
const sequelize = require("../config/sequelize.config");

const SearchBrand = sequelize.define(
  "SearchBrand",
  {
    search_id: { type: DataTypes.TEXT, primaryKey: true },
    brand_id: { type: DataTypes.BIGINT, primaryKey: true },
  },
  {
    tableName: "search_brands",
    timestamps: false,
  }
);

// Define associations
SearchBrand.associate = (models) => {
  // Junction table associations are typically handled by belongsToMany
  // But we can add direct relationships if needed
  SearchBrand.belongsTo(models.Search, {
    foreignKey: 'search_id',
    as: 'search'
  });

  SearchBrand.belongsTo(models.Brand, {
    foreignKey: 'brand_id',
    as: 'brand'
  });
};

module.exports = SearchBrand;
