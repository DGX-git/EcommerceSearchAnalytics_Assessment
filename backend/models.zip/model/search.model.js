const { DataTypes } = require("sequelize");
const sequelize = require("../config/sequelize.config");

const Search = sequelize.define(
  "Search",
  {
    search_id: { type: DataTypes.TEXT, primaryKey: true },
    customer_id: { type: DataTypes.BIGINT },
    search_keyword: DataTypes.TEXT,
    attributes: DataTypes.JSONB,
    min_price: DataTypes.DECIMAL,
    max_price: DataTypes.DECIMAL,
    min_rating: DataTypes.DECIMAL,
    total_results: DataTypes.INTEGER,
    search_date: DataTypes.DATE,
  },
  {
    tableName: "searches",
    timestamps: false,
  }
);

// Define associations
Search.associate = (models) => {
  // Search belongs to Customer
  Search.belongsTo(models.Customer, {
    foreignKey: 'customer_id',
    as: 'customer'
  });

  // Search has one SearchMetric
  Search.hasOne(models.SearchMetric, {
    foreignKey: 'search_id',
    as: 'metrics'
  });

  // Search has many IpAddresses
  Search.hasMany(models.IpAddress, {
    foreignKey: 'search_id',
    as: 'ipAddresses'
  });

  // Many-to-Many: Search <-> Brand through SearchBrand
  Search.belongsToMany(models.Brand, {
    through: models.SearchBrand,
    foreignKey: 'search_id',
    otherKey: 'brand_id',
    as: 'brands'
  });

  // Many-to-Many: Search <-> Category through SearchCategory
  Search.belongsToMany(models.Category, {
    through: models.SearchCategory,
    foreignKey: 'search_id',
    otherKey: 'category_id',
    as: 'categories'
  });

  // Many-to-Many: Search <-> Collection through SearchCollection
  Search.belongsToMany(models.Collection, {
    through: models.SearchCollection,
    foreignKey: 'search_id',
    otherKey: 'collection_id',
    as: 'collections'
  });
};

module.exports = Search;
