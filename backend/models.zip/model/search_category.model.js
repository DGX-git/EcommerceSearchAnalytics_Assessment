const { DataTypes } = require("sequelize");
const sequelize = require("../config/sequelize.config");

const SearchCategory = sequelize.define(
  "SearchCategory",
  {
    search_id: { type: DataTypes.TEXT, primaryKey: true },
    category_id: { type: DataTypes.BIGINT, primaryKey: true },
  },
  {
    tableName: "search_categories",
    timestamps: false,
  }
);

// Define associations
SearchCategory.associate = (models) => {
  // Junction table associations
  SearchCategory.belongsTo(models.Search, {
    foreignKey: 'search_id',
    as: 'search'
  });

  SearchCategory.belongsTo(models.Category, {
    foreignKey: 'category_id',
    as: 'category'
  });
};

module.exports = SearchCategory;
