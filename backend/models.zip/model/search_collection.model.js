const { DataTypes } = require("sequelize");
const sequelize = require("../config/sequelize.config");

const SearchCollection = sequelize.define(
  "SearchCollection",
  {
    search_id: { type: DataTypes.TEXT, primaryKey: true },
    collection_id: { type: DataTypes.BIGINT, primaryKey: true },
  },
  {
    tableName: "search_collections",
    timestamps: false,
  }
);

// Define associations
SearchCollection.associate = (models) => {
  // Junction table associations
  SearchCollection.belongsTo(models.Search, {
    foreignKey: 'search_id',
    as: 'search'
  });

  SearchCollection.belongsTo(models.Collection, {
    foreignKey: 'collection_id',
    as: 'collection'
  });
};

module.exports = SearchCollection;
